from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import torch
from PIL import Image

from .headwise_cache import HeadwiseCacheState
from .methods import (
    DynamicPruneState,
    KVSmoothState,
    decode_visual_scores,
    fuse_scores,
    future_proxy_positions,
    mmshift_scores,
    myopia_scores,
)


Tensor = torch.Tensor


@dataclass(frozen=True)
class GenerationResult:
    caption: str
    output_token_count: int
    elapsed_seconds: float
    peak_gpu_memory_bytes: int
    pruning_events: list[dict[str, Any]]
    method_trace: dict[str, Any]


class TransformersRuntime:
    """Single-GPU Qwen3-VL runtime with an owned eager attention/cache loop."""

    def __init__(
        self,
        config: Mapping[str, Any],
        resource_lock: Mapping[str, Any],
        variant: str,
    ) -> None:
        from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

        self.config = config
        self.variant = variant
        self.device = torch.device(str(config["model"]["device"]))
        if self.device.type != "cuda" or not torch.cuda.is_available():
            raise RuntimeError("the benchmark requires a CUDA GPU")

        model_path = str(Path(resource_lock["model"]["path"]))
        self.processor = AutoProcessor.from_pretrained(
            model_path,
            trust_remote_code=bool(config["model"]["trust_remote_code"]),
        )
        self.model = Qwen3VLForConditionalGeneration.from_pretrained(
            model_path,
            torch_dtype=torch.bfloat16,
            attn_implementation="eager",
            low_cpu_mem_usage=True,
            trust_remote_code=bool(config["model"]["trust_remote_code"]),
        ).to(self.device)
        self.model.eval()
        self._apply_quantization()

    def _apply_quantization(self) -> None:
        quantization = str(self.config["model"]["quantization"])
        if quantization == "bf16":
            return
        if quantization != "torchao_fp8_per_tensor":
            raise ValueError(f"unsupported local quantization: {quantization}")
        try:
            from torchao.quantization import (
                Float8DynamicActivationFloat8WeightConfig,
                PerTensor,
                quantize_,
            )
        except ImportError as error:
            raise RuntimeError(
                "TorchAO is required for FP8 local inference; run doctor"
            ) from error
        quantize_(
            self.model,
            Float8DynamicActivationFloat8WeightConfig(granularity=PerTensor()),
            device=self.device,
        )

    def generate(self, sample: Mapping[str, Any]) -> GenerationResult:
        with torch.inference_mode():
            return self._generate(sample)

    def _generate(self, sample: Mapping[str, Any]) -> GenerationResult:
        from transformers import DynamicCache

        torch.cuda.synchronize(self.device)
        torch.cuda.reset_peak_memory_stats(self.device)
        started = time.perf_counter()

        with Image.open(sample["image_path"]) as image:
            inputs = self._prepare_inputs(image.convert("RGB"), str(sample["prompt"]))
        input_ids = inputs["input_ids"]
        attention_mask = inputs.get("attention_mask")
        prompt_length = input_ids.shape[1]
        cache_position = torch.arange(prompt_length, device=self.device)
        position_ids, rope_delta = self.model.model.get_rope_index(
            input_ids,
            inputs.get("image_grid_thw"),
            None,
            attention_mask=attention_mask,
        )
        position_ids = position_ids.to(self.device)
        rope_delta = rope_delta.to(self.device)
        self.model.model.rope_deltas = rope_delta

        image_mask = input_ids[0].eq(self.model.config.image_token_id)
        if not image_mask.any():
            raise RuntimeError("processor output contains no image tokens")
        text_mask = self._text_query_mask(input_ids[0], attention_mask)
        cache = DynamicCache(config=self.model.config)
        session = _AttentionSession(
            runtime=self,
            cache=cache,
            image_mask=image_mask,
            text_mask=text_mask,
            prefill_position_ids=position_ids,
            sample_id=int(sample["sample_id"]),
        )

        session.install()
        try:
            session.begin_prefill()
            outputs = self.model(
                **inputs,
                position_ids=position_ids,
                cache_position=cache_position,
                past_key_values=cache,
                use_cache=True,
                logits_to_keep=1,
            )
            prefill = session.finish_prefill()
            result = self._decode(
                outputs.logits[0, -1],
                cache,
                session,
                image_mask,
                prefill,
                prompt_length,
                rope_delta,
            )
        finally:
            session.remove()

        torch.cuda.synchronize(self.device)
        elapsed = time.perf_counter() - started
        caption = self.processor.decode(
            result["tokens"],
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        ).strip()
        return GenerationResult(
            caption=caption,
            output_token_count=len(result["tokens"]),
            elapsed_seconds=elapsed,
            peak_gpu_memory_bytes=int(torch.cuda.max_memory_allocated(self.device)),
            pruning_events=result["pruning_events"],
            method_trace={
                "runtime": "transformers_eager",
                "quantization": self.config["model"]["quantization"],
                "prompt_tokens": prompt_length,
                "generated_tokens": len(result["tokens"]),
                "initial_visual_tokens": int(image_mask.sum()),
                "final_visual_tokens": result["final_visual_tokens"],
                "kvsmooth": result["kvsmooth"],
            },
        )

    def _prepare_inputs(self, image: Image.Image, prompt: str) -> dict[str, Tensor]:
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image"},
                    {"type": "text", "text": prompt},
                ],
            }
        ]
        text = self.processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        batch = self.processor(
            text=[text],
            images=[image],
            padding=False,
            return_tensors="pt",
        )
        allowed = {"input_ids", "attention_mask", "pixel_values", "image_grid_thw"}
        return {
            key: value.to(self.device)
            for key, value in batch.items()
            if key in allowed and isinstance(value, Tensor)
        }

    def _text_query_mask(
        self, input_ids: Tensor, attention_mask: Tensor | None
    ) -> Tensor:
        vision_end = input_ids.eq(self.model.config.vision_end_token_id).nonzero(
            as_tuple=False
        )
        start = int(vision_end[-1]) + 1 if vision_end.numel() else 0
        mask = torch.arange(input_ids.numel(), device=input_ids.device) >= start
        if attention_mask is not None:
            mask &= attention_mask[0].bool()
        special_ids = torch.tensor(
            self.processor.tokenizer.all_special_ids,
            device=input_ids.device,
            dtype=input_ids.dtype,
        )
        if special_ids.numel():
            mask &= ~torch.isin(input_ids, special_ids)
        return mask

    def _decode(
        self,
        first_logits: Tensor,
        cache: Any,
        session: "_AttentionSession",
        image_mask: Tensor,
        prefill: "_PrefillScores",
        prompt_length: int,
        rope_delta: Tensor,
    ) -> dict[str, Any]:
        dynamic = self.variant in {"prunehal", "core4_no_rb"}
        static = self.variant in {"mmshift", "myopia_score"}
        smooth = self.variant in {"kvsmooth", "core4_no_rb"}
        tracker: HeadwiseCacheState | None = None
        pruning_events: list[dict[str, Any]] = []

        if dynamic or static:
            tracker = HeadwiseCacheState.from_prefill(
                cache,
                image_mask,
                shift_scores=prefill.shift,
                text_scores=prefill.text,
            )
        if static and tracker is not None:
            budget_key = "mmshift" if self.variant == "mmshift" else "myopia"
            keep_count = min(
                tracker.visual_count,
                int(self.config[budget_key]["cache_budget"]),
            )
            if keep_count < tracker.visual_count:
                scores = (
                    tracker.shift_scores
                    if self.variant == "mmshift"
                    else tracker.text_scores
                )
                pruned = tracker.prune(scores, keep_count)
                pruning_events.append(
                    _prune_event(
                        step=0,
                        trigger="prefill_budget",
                        votes=None,
                        layer_visual_mass=None,
                        pruned=pruned,
                    )
                )

        prune_state = None
        if dynamic:
            prune_config = self.config["prunehal"]
            prune_state = DynamicPruneState(
                retention_ratio=float(prune_config["retention_ratio"]),
                max_prunes=int(prune_config["max_prunes"]),
                force_step=int(prune_config["force_step"]),
                vote_fraction=float(prune_config["vote_fraction"]),
            )
            triggered, _ = prune_state.observe(prefill.layer_visual_mass)
            if triggered:
                raise AssertionError("prefill reference unexpectedly triggered pruning")

        eos_ids = self.model.generation_config.eos_token_id
        if eos_ids is None:
            eos_ids = self.processor.tokenizer.eos_token_id
        eos_set = {int(eos_ids)} if isinstance(eos_ids, int) else set(map(int, eos_ids))
        max_tokens = int(self.config["decoding"]["max_new_tokens"])
        tokens: list[int] = []
        next_logits = first_logits
        kvsmooth_summary: dict[str, Any] = {
            "step_count": 0,
            "layer_update_count": 0,
            "coefficient_sum": 0.0,
            "coefficient_min": None,
            "coefficient_max": None,
            "entropy_sum": 0.0,
            "entropy_min": None,
            "entropy_max": None,
        }

        while len(tokens) < max_tokens:
            token = int(torch.argmax(next_logits.float()).item())
            tokens.append(token)
            if token in eos_set or len(tokens) == max_tokens:
                break

            current_image_mask = tracker.image_mask if tracker is not None else image_mask
            session.begin_decode(
                current_image_mask=current_image_mask,
                collect_dynamic=dynamic,
                apply_kvsmooth=smooth,
            )
            absolute_position = prompt_length + len(tokens) - 1
            cache_position = torch.tensor([absolute_position], device=self.device)
            text_position = cache_position[0] + rope_delta[0, 0]
            decode_position_ids = text_position.view(1, 1, 1).expand(3, 1, 1)
            outputs = self.model(
                input_ids=torch.tensor([[token]], device=self.device),
                position_ids=decode_position_ids,
                cache_position=cache_position,
                past_key_values=cache,
                use_cache=True,
                logits_to_keep=1,
            )
            decode = session.finish_decode()
            if decode.kvsmooth:
                _update_kvsmooth_summary(kvsmooth_summary, decode.kvsmooth)
            if tracker is not None and dynamic:
                tracker.append_nonvisual(absolute_position)

            if dynamic:
                assert prune_state is not None and tracker is not None
                triggered, votes = prune_state.observe(decode.layer_visual_mass)
                if triggered:
                    keep_count = prune_state.next_visual_count(tracker.visual_count)
                    if self.variant == "prunehal":
                        scores = decode.scores
                    else:
                        weights = self.config["fusion"]
                        fusion_weights = (
                            float(weights["decode"]),
                            float(weights["shift"]),
                            float(weights["text"]),
                        )
                        scores = torch.stack(
                            [
                                fuse_scores(
                                    decode.scores[layer],
                                    tracker.shift_scores[layer],
                                    tracker.text_scores[layer],
                                    tracker.image_mask,
                                    weights=fusion_weights,
                                )
                                for layer in range(decode.scores.shape[0])
                            ]
                        )
                    pruned = tracker.prune(scores, keep_count)
                    pruning_events.append(
                        _prune_event(
                            step=prune_state.step,
                            trigger="forced" if prune_state.step == 2 else "layer_vote",
                            votes=votes,
                            layer_visual_mass=decode.layer_visual_mass,
                            pruned=pruned,
                        )
                    )

            next_logits = outputs.logits[0, -1]

        final_visual = tracker.visual_count if tracker is not None else int(image_mask.sum())
        return {
            "tokens": tokens,
            "pruning_events": pruning_events,
            "final_visual_tokens": final_visual,
            "kvsmooth": _finish_kvsmooth_summary(kvsmooth_summary),
        }


@dataclass(frozen=True)
class _PrefillScores:
    shift: Tensor | None
    text: Tensor | None
    layer_visual_mass: Tensor | None


@dataclass(frozen=True)
class _DecodeScores:
    scores: Tensor | None
    layer_visual_mass: Tensor | None
    kvsmooth: list[dict[str, float]]


class _AttentionSession:
    def __init__(
        self,
        *,
        runtime: TransformersRuntime,
        cache: Any,
        image_mask: Tensor,
        text_mask: Tensor,
        prefill_position_ids: Tensor,
        sample_id: int,
    ) -> None:
        self.runtime = runtime
        self.model = runtime.model
        self.config = runtime.config
        self.variant = runtime.variant
        self.cache = cache
        self.image_mask = image_mask
        self.text_mask = text_mask
        self.prefill_position_ids = prefill_position_ids
        self.sample_id = sample_id
        self.phase = "off"
        self.current_image_mask = image_mask
        self.collect_dynamic = False
        self.apply_kvsmooth = False
        self.handles = []
        self.shift: list[Tensor | None] = []
        self.text: list[Tensor | None] = []
        self.prefill_mass: list[Tensor | None] = []
        self.decode_scores: list[Tensor | None] = []
        self.decode_mass: list[Tensor | None] = []
        self.smoothing: list[dict[str, float]] = []
        smooth_config = self.config["kvsmooth"]
        self.kvsmooth = KVSmoothState(
            first_layer=int(smooth_config["first_layer"]),
            last_layer=int(smooth_config["last_layer"]),
            fifo_size=int(smooth_config["fifo_size"]),
            lambda_ref=float(smooth_config["lambda_ref"]),
            clip_radius=float(smooth_config["clip_radius"]),
        )

    def install(self) -> None:
        for layer_idx, decoder_layer in enumerate(self.model.language_model.layers):
            handle = decoder_layer.self_attn.register_forward_hook(
                self._hook(layer_idx), with_kwargs=True
            )
            self.handles.append(handle)

    def remove(self) -> None:
        for handle in self.handles:
            handle.remove()
        self.handles.clear()

    def begin_prefill(self) -> None:
        layer_count = len(self.model.language_model.layers)
        self.phase = "prefill"
        self.shift = [None] * layer_count
        self.text = [None] * layer_count
        self.prefill_mass = [None] * layer_count

    def finish_prefill(self) -> _PrefillScores:
        self.phase = "off"
        shift = _stack_optional(self.shift, self.variant in {"mmshift", "core4_no_rb"})
        text = _stack_optional(self.text, self.variant in {"myopia_score", "core4_no_rb"})
        mass = _stack_optional(
            self.prefill_mass, self.variant in {"prunehal", "core4_no_rb"}
        )
        return _PrefillScores(shift=shift, text=text, layer_visual_mass=mass)

    def begin_decode(
        self,
        *,
        current_image_mask: Tensor,
        collect_dynamic: bool,
        apply_kvsmooth: bool,
    ) -> None:
        layer_count = len(self.model.language_model.layers)
        self.phase = "decode"
        self.current_image_mask = current_image_mask
        self.collect_dynamic = collect_dynamic
        self.apply_kvsmooth = apply_kvsmooth
        self.decode_scores = [None] * layer_count
        self.decode_mass = [None] * layer_count
        self.smoothing = []

    def finish_decode(self) -> _DecodeScores:
        self.phase = "off"
        scores = _stack_optional(self.decode_scores, self.collect_dynamic)
        mass = _stack_optional(self.decode_mass, self.collect_dynamic)
        return _DecodeScores(scores=scores, layer_visual_mass=mass, kvsmooth=self.smoothing)

    def _hook(self, layer_idx: int):
        def hook(module, args, kwargs, output):
            if self.phase == "off":
                return
            attention = output[1]
            if attention is None:
                raise RuntimeError("eager attention did not return attention probabilities")
            if self.phase == "prefill":
                self._collect_prefill(layer_idx, module, kwargs, attention[0])
            elif self.phase == "decode":
                self._collect_decode(layer_idx, attention[0])

        return hook

    def _collect_prefill(
        self,
        layer_idx: int,
        module: Any,
        kwargs: Mapping[str, Any],
        attention: Tensor,
    ) -> None:
        if self.variant in {"mmshift", "core4_no_rb"}:
            self.shift[layer_idx] = self._mmshift(layer_idx, module, kwargs)
        if self.variant in {"myopia_score", "core4_no_rb"}:
            self.text[layer_idx] = myopia_scores(
                attention,
                self.image_mask,
                self.text_mask,
                num_kv_heads=int(self.model.config.text_config.num_key_value_heads),
                text_alpha=float(self.config["myopia"]["text_alpha"]),
            )
        if self.variant in {"prunehal", "core4_no_rb"}:
            self.prefill_mass[layer_idx] = (
                attention[:, -1, self.image_mask].float().mean()
            )

    def _mmshift(
        self, layer_idx: int, module: Any, kwargs: Mapping[str, Any]
    ) -> Tensor:
        hidden = kwargs["hidden_states"][0]
        settings = self.config["mmshift"]
        num_proxies = int(settings["num_proxies"])
        num_groups = int(settings["num_groups"])
        generator = torch.Generator(device=hidden.device)
        generator.manual_seed(
            int(self.config["seed"]) + self.sample_id * 1009 + layer_idx
        )
        mean = hidden.float().mean(dim=0)
        std = hidden.float().std(dim=0, unbiased=False)
        noise = torch.randn(
            (num_proxies, hidden.shape[-1]),
            generator=generator,
            device=hidden.device,
            dtype=torch.float32,
        )
        sampled = (mean + float(settings["variance_gamma"]) * std * noise).to(
            hidden.dtype
        )
        query_heads = int(self.model.config.text_config.num_attention_heads)
        projected = module.q_proj(sampled).view(
            num_proxies, query_heads, module.head_dim
        )
        projected = module.q_norm(projected).transpose(0, 1)

        last_position = int(self.prefill_position_ids.max())
        proxy_positions = future_proxy_positions(
            last_position,
            num_proxies,
            num_groups,
            device=hidden.device,
        )
        proxy_position_ids = proxy_positions.view(1, 1, -1).expand(3, 1, -1)
        cos, sin = self.model.language_model.rotary_emb(
            sampled.unsqueeze(0), proxy_position_ids
        )
        proxy_queries = _apply_rope(projected, cos[0], sin[0])

        real_queries = module.q_proj(hidden[-1:]).view(1, query_heads, module.head_dim)
        real_queries = module.q_norm(real_queries).transpose(0, 1)
        real_cos, real_sin = kwargs["position_embeddings"]
        last_query = _apply_rope(
            real_queries, real_cos[0, -1:], real_sin[0, -1:]
        ).squeeze(1)
        prompt_keys = self.cache.layers[layer_idx].keys[0]
        return mmshift_scores(
            proxy_queries,
            prompt_keys,
            last_query,
            num_groups=num_groups,
            mass_threshold=float(settings["mass_threshold"]),
            anchor=float(settings["anchor"]),
        )

    def _collect_decode(self, layer_idx: int, attention: Tensor) -> None:
        query_length = attention.shape[-2]
        extended_mask = torch.cat(
            (
                self.current_image_mask,
                torch.zeros(
                    query_length,
                    dtype=torch.bool,
                    device=self.current_image_mask.device,
                ),
            )
        )
        if self.collect_dynamic:
            self.decode_scores[layer_idx] = decode_visual_scores(
                attention,
                extended_mask,
                num_kv_heads=int(self.model.config.text_config.num_key_value_heads),
            )
            self.decode_mass[layer_idx] = (
                attention[:, -1, extended_mask].float().mean()
            )
        if self.apply_kvsmooth and self.kvsmooth.includes(layer_idx):
            layer = self.cache.layers[layer_idx]
            if layer.keys.shape[-2] < 2:
                raise AssertionError("KVSmooth requires a previous cache token")
            coefficient, entropy = self.kvsmooth.coefficient(layer_idx, attention)
            layer.keys[:, :, -1, :] = (
                (1 - coefficient) * layer.keys[:, :, -1, :]
                + coefficient * layer.keys[:, :, -2, :]
            )
            layer.values[:, :, -1, :] = (
                (1 - coefficient) * layer.values[:, :, -1, :]
                + coefficient * layer.values[:, :, -2, :]
            )
            self.smoothing.append(
                {
                    "layer": float(layer_idx),
                    "lambda": float(coefficient),
                    "entropy": float(entropy),
                }
            )


def _apply_rope(states: Tensor, cos: Tensor, sin: Tensor) -> Tensor:
    half = states.shape[-1] // 2
    rotated = torch.cat((-states[..., half:], states[..., :half]), dim=-1)
    return states * cos.unsqueeze(0) + rotated * sin.unsqueeze(0)


def _stack_optional(values: list[Tensor | None], required: bool) -> Tensor | None:
    if not required:
        return None
    if any(value is None for value in values):
        raise RuntimeError("attention hook did not collect every decoder layer")
    return torch.stack([value for value in values if value is not None])


def _update_kvsmooth_summary(
    summary: dict[str, Any], rows: list[dict[str, float]]
) -> None:
    summary["step_count"] += 1
    summary["layer_update_count"] += len(rows)
    for row in rows:
        coefficient = float(row["lambda"])
        entropy = float(row["entropy"])
        summary["coefficient_sum"] += coefficient
        summary["entropy_sum"] += entropy
        summary["coefficient_min"] = (
            coefficient
            if summary["coefficient_min"] is None
            else min(summary["coefficient_min"], coefficient)
        )
        summary["coefficient_max"] = (
            coefficient
            if summary["coefficient_max"] is None
            else max(summary["coefficient_max"], coefficient)
        )
        summary["entropy_min"] = (
            entropy
            if summary["entropy_min"] is None
            else min(summary["entropy_min"], entropy)
        )
        summary["entropy_max"] = (
            entropy
            if summary["entropy_max"] is None
            else max(summary["entropy_max"], entropy)
        )


def _finish_kvsmooth_summary(summary: dict[str, Any]) -> dict[str, Any]:
    result = dict(summary)
    updates = int(result["layer_update_count"])
    coefficient_sum = float(result.pop("coefficient_sum"))
    entropy_sum = float(result.pop("entropy_sum"))
    result["coefficient_mean"] = coefficient_sum / updates if updates else None
    result["entropy_mean"] = entropy_sum / updates if updates else None
    return result


def _prune_event(
    *,
    step: int,
    trigger: str,
    votes: Tensor | None,
    layer_visual_mass: Tensor | None,
    pruned: Any,
) -> dict[str, Any]:
    return {
        "decode_step": int(step),
        "trigger": trigger,
        "layer_votes": None if votes is None else votes.detach().cpu().tolist(),
        "layer_visual_mass": (
            None
            if layer_visual_mass is None
            else layer_visual_mass.detach().cpu().tolist()
        ),
        "before_visual_count": pruned.before_visual_count,
        "after_visual_count": pruned.after_visual_count,
        "selected_original_visual_positions": (
            pruned.selected_original_visual_positions.detach().cpu().tolist()
        ),
    }
