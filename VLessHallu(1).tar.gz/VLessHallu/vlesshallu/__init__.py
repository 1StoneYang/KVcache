"""VLessHallu benchmark package."""

__version__ = "0.2.0"
